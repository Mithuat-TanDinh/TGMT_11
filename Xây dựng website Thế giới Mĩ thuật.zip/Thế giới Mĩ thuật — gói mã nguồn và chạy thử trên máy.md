# Thế giới Mĩ thuật — gói mã nguồn và chạy thử trên máy

Gói này gồm hai phần:

- **`ready-to-run/`**: bản website đã biên dịch thành HTML, CSS và JavaScript để chạy thử nhanh.
- **`source/`**: mã nguồn có thể chỉnh sửa (React + TypeScript/TSX, CSS), kèm cấu hình và khóa phiên bản thư viện.

## Cách nhanh trên Windows

1. Giải nén toàn bộ tệp ZIP vào một thư mục trên máy tính.
2. Cài Python 3 nếu máy chưa có (khi cài, bật tùy chọn thêm Python vào `PATH`).
3. Nhấp đúp **`start_preview_windows.bat`**. Cửa sổ lệnh sẽ mở máy chủ xem thử; giữ cửa sổ này mở.
4. Mở trình duyệt và vào `http://127.0.0.1:8765`.
5. Khi xem xong, quay lại cửa sổ lệnh và nhấn `Ctrl+C` để dừng.

## Cách nhanh trên macOS / Linux

1. Giải nén ZIP.
2. Mở Terminal tại thư mục vừa giải nén.
3. Chạy `./start_preview_macos_linux.sh` (nếu cần quyền chạy: `chmod +x start_preview_macos_linux.sh`).
4. Mở `http://127.0.0.1:8765` trong trình duyệt. Dừng bằng `Ctrl+C`.

Cả hai cách trên dùng máy chủ tĩnh cục bộ để các tệp HTML, CSS, JavaScript và hình ảnh tải đúng; không mở `ready-to-run/index.html` bằng cách nhấp đúp vì trình duyệt có thể chặn tài nguyên khi dùng địa chỉ `file://`.

## Chạy từ mã nguồn để chỉnh sửa

Cần Node.js 20 LTS trở lên và pnpm. Trong Terminal/PowerShell:

```bash
cd source
corepack enable
pnpm install --frozen-lockfile
pnpm dev
```

Sau đó mở `http://localhost:3000`. Dừng máy chủ bằng `Ctrl+C`. Khi sửa mã nguồn, các trang sẽ tự cập nhật trong lúc phát triển.

## Lưu ý về bản xem trước

Đây là bản chạy thử cục bộ, không phải bản đã xuất bản. Chưa kết nối Supabase/Netlify và không chứa secret key. Tiến độ, bài hát, tệp MP3, ảnh bìa và URL trò chơi do người dùng thêm được lưu cục bộ trong trình duyệt (Local Storage / IndexedDB) trên chính máy này; chúng không tự đồng bộ sang máy hoặc trình duyệt khác. Xóa dữ liệu trang web của trình duyệt có thể làm mất dữ liệu xem thử đã thêm.

Gói giữ các hoạt động và giao diện hiện tại. Hai ảnh minh họa đã được đưa vào gói để chạy local. Google Fonts có thể cần Internet; nếu không có mạng, trang dùng font thay thế của hệ thống. Các URL trò chơi ngoài do người dùng tự thêm vẫn cần Internet và có thể không cho nhúng trong iframe.

Tệp đầu vào không yêu cầu cài đặt database và không chạy bất kỳ câu lệnh SQL nào.
