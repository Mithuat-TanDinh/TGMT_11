# Kế hoạch triển khai — Thế giới Mĩ thuật

## Phạm vi và kiến trúc

Dựng bản xem trước website giáo dục tương tác bằng tiếng Việt cho học sinh lớp 1–5. Stack: React, TypeScript và Vite; giao diện responsive cho điện thoại, máy tính bảng và máy tính. Chia mã theo các khu vực UI, trò chơi học tập, xưởng sáng tạo, dịch vụ lưu trữ xem trước và kiểu dữ liệu. Hiện tại không bật backend/manus database, không kết nối Supabase, GitHub hay Netlify, và không xuất bản. Dữ liệu thêm trong bản xem trước chỉ được lưu trên trình duyệt hiện tại (IndexedDB/local storage); đây không phải xác thực hoặc phân quyền an toàn, không dùng dữ liệu nhạy cảm của học sinh. Khi chưa có nội dung do giáo viên cung cấp, các thư viện hiển thị trạng thái trống thay vì dữ liệu giả.

Giai đoạn sau có thể kết nối Supabase Auth, Database và Storage để cung cấp đăng nhập giáo viên, quyền truy cập, thư viện dùng chung và lưu MP3/ảnh; không thực hiện trong bản xem trước này. Chỉ chứa biến môi trường mẫu, tuyệt đối không có khóa bí mật trong mã nguồn.

## Thiết kế

**Ứng viên phong cách (xác suất):** truyện tranh đồng quê dân gian 2D (8%); xưởng giấy cắt ghép (5%); màu nước cổ tích (2%). Chọn truyện tranh đồng quê dân gian 2D.

- **Chuyển động thiết kế:** minh họa truyện tranh đồng quê 2D cho trẻ tiểu học.
- **Nguyên tắc cốt lõi:** vui tươi nhưng dễ đọc; điều hướng theo hành trình; tương tác ít bước, phản hồi rõ; responsive và tôn trọng riêng tư.
- **Màu sắc:** nền kem giấy dịu mắt, xanh lá làm màu nhận diện, điểm nhấn đỏ gạch/vàng nắng tạo cảm giác khám phá.
- **Bố cục:** bản đồ/hành trình theo từng trạm khám phá; thẻ nội dung rõ ràng, không phụ thuộc lưới giữa trang.
- **Dấu ấn:** nét vẽ phấn/giấy; huy hiệu hình cọ vẽ; đường mòn nối các trạm.
- **Tương tác/hoạt ảnh:** nút lớn, trạng thái focus rõ; chuyển động nhẹ khi chọn trạm và nhận huy hiệu; tôn trọng prefers-reduced-motion.
- **Chữ:** Baloo 2 cho tiêu đề; Nunito cho nội dung; cỡ chữ đọc tốt trên màn hình nhỏ, hỗ trợ tiếng Việt có dấu.
- **Tinh thần thương hiệu:** thế giới khám phá nghệ thuật cho học sinh tiểu học, nơi bài học thành chuyến phiêu lưu; hồn nhiên, gần gũi, khích lệ.
- **Giọng điệu:** lời ngắn, thân thiện, động viên; ví dụ “Nào, mình cùng khám phá nhé!” và “Mỗi nét vẽ là một ý tưởng mới.”
- **Logo:** dấu cọ vẽ tạo thành mặt trời nhỏ đang mọc sau trang giấy, đi cùng chữ “Thế giới Mĩ thuật”.
- **Màu thương hiệu riêng:** xanh lá đồng quê.

## Các khu vực

1. **Trang chủ:** tên/logo, lời chào, điều hướng đến các khu vực dưới dạng hành trình/nút lớn.
2. **Góc Âm nhạc:** chọn/tải MP3, kiểm tra định dạng và dung lượng, thông tin bài hát/ảnh/lời, tìm kiếm, phân loại chủ đề/khối, play/pause/next/previous/volume, thêm/sửa/xóa cục bộ và trạng thái trống khi chưa có nội dung.
3. **Trò chơi học tập:** phân loại lớp 1–5; biểu mẫu thêm/sửa/xóa trò chơi (tên, mô tả, lớp, URL), nhúng iframe khi được phép, mở tab mới, báo lỗi/trạng thái khi không nhúng được.
4. **Khám phá:** bản đồ làng quê cổ tích, nhân vật/vật phẩm/nhiệm vụ/điểm thưởng được thể hiện như định hướng cho trò chơi riêng tương lai; đánh dấu đây là khu vực đang chuẩn bị.
5. **Xưởng Sáng tạo:** trò chơi thực sự tương tác: ghép từ/câu, sắp xếp bước vẽ, nhận biết màu, hình cơ bản và sản phẩm Mĩ thuật.
6. **Thành tích:** nhiệm vụ và điểm/huy hiệu trên trình duyệt hiện tại, không yêu cầu công khai thông tin cá nhân nhạy cảm.
7. **Quản trị giáo viên (xem trước):** giao diện quản lý nội dung, thông báo rõ chế độ cục bộ; không tuyên bố là truy cập riêng/an toàn cho giáo viên đến khi có Auth/RLS từ backend.

## Cấu trúc dự kiến

- `src/app/`: khung ứng dụng, định tuyến/điều hướng và layout responsive.
- `src/components/`: nút, thẻ trạm, trạng thái rỗng, modal và thành phần dùng chung.
- `src/features/home/`, `music/`, `games/`, `explore/`, `workshop/`, `achievements/`, `teacher/`: giao diện và tương tác theo từng khu vực.
- `src/lib/`: kiểu dữ liệu, xác thực đầu vào, lưu trữ trình duyệt và tiện ích media.
- `public/assets/`: minh họa gốc cho bản xem trước.
- `public/manus-routes.json`: khai báo route trang.
- `plan.md`, `TODO.md`, `README.md`, `.env.example`: kế hoạch, tiêu chí công việc, hướng dẫn và biến môi trường mẫu.

## Giới hạn bàn giao

Bản xem trước chưa nối Supabase nên đăng nhập an toàn, lưu trữ MP3/ảnh dùng chung, đồng bộ thiết bị, xác thực riêng cho giáo viên và phân quyền RLS chưa được bật. Chưa kết nối GitHub/Netlify, chưa xuất bản. Không tự ý thay đổi/xóa dữ liệu hoặc dự án bên ngoài.