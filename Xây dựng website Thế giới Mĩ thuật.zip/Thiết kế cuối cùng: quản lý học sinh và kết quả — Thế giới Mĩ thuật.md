# Thiết kế cuối cùng: quản lý học sinh và kết quả — Thế giới Mĩ thuật

**Trạng thái: thiết kế chờ phê duyệt riêng trước triển khai.** Đã cập nhật theo xác nhận ngày 25-11-2026 và kiểm tra mã hiện tại. Chưa tạo bảng, chạy SQL, sửa mã nguồn, thêm khóa bí mật, kết nối ghi dữ liệu, thay đổi Supabase hay xuất bản website.

## 1. Các quyết định đã xác nhận

- Mỗi học sinh có một `student_code` duy nhất trong toàn trường, giữ nguyên khi chuyển lớp. Mã là định danh roster, không phải mật khẩu.
- Học sinh không có email/tài khoản cá nhân. Mặc định nhập họ tên và chọn lớp. Nếu tên trùng trong cùng lớp, hệ thống yêu cầu thêm mã học sinh trước khi tạo lượt. Không có tài khoản Supabase cá nhân hiển thị cho học sinh; phiên Auth ẩn danh do website khởi tạo là chi tiết kỹ thuật.
- Với trò có đáp án đúng/sai, đáp án chuẩn chỉ nằm phía server, Edge Functions chấm từ các lựa chọn gửi lên. Không đưa đáp án vào JavaScript tải về trình duyệt.
- Quản trị viên tối cao là chủ hệ thống; giáo viên khác chỉ xem/quản lý lớp được phân công. Kết quả và xếp hạng không công khai.
- Supabase Free hiện không có backup database tự động hằng ngày theo tài liệu Supabase; đề xuất dump database hằng đêm được mã hóa, lưu ngoài project, giữ bản 30 ngày và thử khôi phục định kỳ. Chi tiết tại mục 10.
- Giữ nguyên toàn bộ giao diện, hình ảnh, nội dung, luật và tương tác của năm hoạt động; chỉ thêm lớp kỹ thuật thu nhận/lưu kết quả.

## 2. Phân loại 5 hoạt động hiện có

Đã đọc danh sách `activities`, logic kiểm tra đáp án và thứ tự bước trong `src/app/App.tsx`. Bảng dưới phân biệt loại bài tập theo mã hiện tại, không suy đoán theo tên.

| Mã / tên hiện tại | Cách hoạt động hiện tại | Phân loại | Trạng thái điểm phù hợp khi tích hợp |
|---|---|---|---|
| `match` — Ghép hình với câu | 3 câu lựa chọn; mỗi câu có một đáp án đúng được định nghĩa trong mã, sai thì hiện nhắc thử lại. | Có câu hỏi và đáp án đúng/sai cố định. | Có thể `server_verified` sau khi chuyển 3 câu/đáp án lên vùng private và chấm từng lựa chọn trên server. |
| `steps` — Xếp bước vẽ | Sắp xếp 3 bước theo thứ tự; thứ tự đúng hiện tại là `2,1,0`; có thể thử lại. | Không phải trắc nghiệm, nhưng có thứ tự đáp án cố định và kiểm chứng được. | Có thể `server_verified` như bài sắp xếp 1 mục/3 vị trí; server xác minh hoán vị cuối cùng. Không ghi điểm đến khi đúng/hoàn tất, giữ cách thử lại hiện hành. |
| `colors` — Nhà thám hiểm màu sắc | 3 câu lựa chọn, mỗi câu có đáp án cố định trong `checkActivity`. | Có câu hỏi và đáp án đúng/sai cố định. | Có thể `server_verified` từ 3 lựa chọn chấm phía server. |
| `shapes` — Hình khối vui nhộn | 3 câu lựa chọn về hình dạng, đáp án cố định. | Có câu hỏi và đáp án đúng/sai cố định. | Có thể `server_verified` từ 3 lựa chọn chấm phía server. |
| `artworks` — Bảo tàng tí hon | 3 câu lựa chọn về sản phẩm Mĩ thuật; mỗi câu hiện có một đáp án khớp cố định. | Theo mã hiện tại đây là câu hỏi phân loại có đáp án cố định; **không phải** hoạt động sáng tạo mở cần giáo viên chấm. | Có thể `server_verified` từ 3 lựa chọn chấm phía server. Nếu sau này nội dung đổi thành học sinh tự tạo tác phẩm/đáp án mở thì phải phân loại lại và dùng `teacher_reviewed` hoặc `not_applicable`, không tự gắn `server_verified`. |

**Kết luận kiểm tra:** 4 hoạt động là trắc nghiệm có đáp án cố định; `steps` là bài sắp xếp có đáp án cố định. Không tìm thấy hoạt động nào trong đúng 5 hoạt động hiện tại thuộc nhóm “sáng tạo mở cần giáo viên đánh giá”. Các điểm thưởng `award()` trong mã đang cập nhật thành tích cục bộ và chặn thưởng lặp theo mã nhiệm vụ; chúng không phải hệ thống điểm theo từng lượt chơi. Khi tích hợp, cần ánh xạ kết quả server sang hồ sơ lượt riêng mà không đổi thông báo, hình thức chơi hay quy tắc thưởng đang thấy. Hệ thống không nên tự coi điểm thành tích cục bộ là điểm lượt.

## 3. Sơ đồ kiến trúc

```text
Học sinh (không có tài khoản cá nhân)
  └─ Website hiện tại: họ tên + chọn lớp
       └─ Nếu tên trùng trong lớp: yêu cầu mã học sinh
            └─ Phiên Supabase Auth ẩn danh do ứng dụng tạo
                 ├─ start-attempt: đối chiếu roster, tạo lượt mới, giờ server
                 ├─ submit-answer: gửi lựa chọn/thứ tự, server chấm
                 └─ complete-attempt: server tổng hợp và khóa kết quả
                       ├─ Postgres: roster, trò chơi, lịch sử lượt chơi
                       └─ Schema private: câu hỏi/đáp án chuẩn

Quản trị viên tối cao / giáo viên
  └─ Trang /teacher, Supabase Auth, JWT
       ├─ RLS: admin toàn trường; giáo viên chỉ lớp được phân công
       ├─ import-students / export-results: Excel, kiểm tra quyền phía server
       └─ Học sinh: list-student-classes chỉ trả danh mục lớp an toàn

Sao lưu: Supabase Free → dump database hằng đêm → mã hóa → lưu ngoài project
```

Phiên ẩn danh là token phục vụ kỹ thuật; học sinh không cần email, mật khẩu hoặc tài khoản cá nhân. Token không xác minh danh tính thật. Mã học sinh giúp phân biệt roster nhưng nếu bị chia sẻ vẫn có thể bị dùng để mạo danh. Supabase anonymous users có claim `is_anonymous` và role Postgres `authenticated`; policy phải phân biệt họ với giáo viên [6]. Bật CAPTCHA/Turnstile và giới hạn tốc độ cho luồng tạo phiên ẩn danh [7].

Không có `service_role` hoặc secret key trong frontend. Nếu server-only write cần service-role, chỉ lưu trong Edge Function secrets; vì service-role bỏ qua RLS, dashboard không dùng khóa đó mà dùng JWT giáo viên và RLS [1] [2].

## 4. Bảng dữ liệu và tính nhất quán

Mọi lượt chơi tạo bản ghi mới; không ghi đè lịch sử. Thông tin học sinh/lớp/trò được chụp thành snapshot trong lượt để chuyển lớp hoặc đổi tên về sau không làm sai báo cáo cũ. Với một trường, `student_code` có unique constraint toàn trường. Nếu sau này dự án nhiều trường, uniqueness sẽ là cặp `school_id + student_code`.

| Bảng | Trường đề xuất / nhiệm vụ |
|---|---|
| `classes` | `id`, `class_code`, `class_name`, `grade`, `school_year`, `active`, `created_at`. Danh mục lớp hiện hành. |
| `teacher_profiles` | `user_id` FK tới `auth.users.id`, `display_name`, `role` (`super_admin` hoặc `teacher`), `active`, `created_at`. Chỉ quản trị viên cao nhất mới có thể cấp/thu hồi vai trò; không cho client tự gán role. |
| `teacher_classes` | `teacher_id`, `class_id`, `active`, `created_at`; xác định lớp giáo viên được phân công. Admin tối cao có quyền toàn trường theo policy riêng. |
| `students` | `id`, `student_code` (duy nhất toàn trường, chuẩn hóa), `full_name`, `current_class_id`, `active`, `created_at`. Cập nhật lớp hiện tại khi chuyển lớp; lượt cũ giữ snapshot. Mã không thay đổi khi chuyển lớp. |
| `games` | `id`, `game_code` duy nhất, `game_name`, `current_version`, `active`, `created_at`. Seed 5 mã hoạt động hiện có. |
| `private.game_items` | `game_id`, `game_version`, `item_code`, `item_order`, `prompt_payload`, `answer_key`, `points`, `active`. Schema không expose cho Data API; chỉ hàm chấm server được truy cập. Với `steps`, lưu quy tắc thứ tự đúng. |
| `game_attempts` | Một hàng mỗi lượt: `id`, `start_idempotency_key`, `student_id`, `class_id_at_play`, `game_id`, mã/tên/version snapshot, mã/tên/lớp snapshot, `student_auth_uid`, `score`, `correct_count`, `question_count`, `correct_rate`, `duration_seconds`, `started_at`, `completed_at`, `abandoned_at`, `status`, `verification_status`, `created_at`. Không unique theo học sinh/trò để giữ mọi lần chơi. `verification_status` bắt đầu `pending`; chỉ thành `server_verified` khi server chấm xong. |
| `attempt_responses` | Cần thiết cho chấm server: `id`, `attempt_id`, `game_item_id`, `answer_value`, `is_correct`, `answered_at`, `idempotency_key`. Lưu nhiều lần trả lời sai/thử lại; chống ghi trùng cùng request nhưng vẫn cho thử lại câu sai. Không cho client sửa/xóa response đã ghi. |
| `student_import_batches` | `id`, `class_id`, `created_by`, `created_at`, `status`, `row_count`, `inserted_count`, `updated_count`, `skipped_count`, `error_count`, `file_sha256`. Log quá trình nhập, không giữ file Excel gốc mặc định. |
| `result_export_audit` | `id`, `teacher_id`, `filters`, `created_at`, `row_count`; nhật ký xuất, không lưu bản sao nội dung kết quả. |

Trong `game_attempts`, `score` là điểm chuẩn hóa 0–100; với 5 hoạt động hiện tại các mục có trọng số bằng nhau nên tương đương `100 × correct_count / question_count`. `correct_rate` dùng cùng tỷ lệ không trọng số; `duration_seconds` lấy từ mốc server; `started_at`/`completed_at` là `timestamptz` UTC và dashboard hiển thị giờ Việt Nam. Với `steps`, coi thứ tự là một mục chấm: `correct_count=1`, `question_count=1` khi đúng. Trò hiện tại cho thử lại đến khi đúng; giữ luật này nghĩa là điểm xác minh đo số mục hoàn tất đúng sau các lần thử, **không** đo độ chính xác lần đầu. Câu sai được lưu để audit nhưng không cộng thêm vào tổng câu/điểm; chỉ câu đúng đầu tiên cho mỗi mục được tính. `status`: `in_progress`, `completed`, `abandoned`. `verification_status`: `pending`, `server_verified`, `client_reported`, `teacher_reviewed`, `not_applicable`.

RLS và GRANT phải được rà soát cùng nhau; bật RLS không tự thu hồi GRANT đã có [1]. Để điểm của cả 5 trò được xác minh từ server, `attempt_responses` là bắt buộc. Lưu lựa chọn tối thiểu để tổng hợp và chống gửi trùng; cho phép nhiều response sai để không thay đổi luật thử lại hiện tại, nhưng chỉ một response đúng đầu tiên được tính điểm cho item.

## 5. Roster Excel và bắt đầu lượt

Mẫu Excel `.xlsx` có cột bắt buộc `student_code`, `full_name`, `class_code`; với file chỉ một lớp, giáo viên chọn lớp trước và có thể bỏ cột `class_code`. Giáo viên chỉ nhập lớp được phân công; admin tối cao nhập toàn trường.

Luồng nhập: chọn file → kiểm tra cột/định dạng và giới hạn kích thước → xem trước dòng hợp lệ, mã trùng/trống, tên trống, lớp không hợp lệ hoặc ngoài quyền → giáo viên xác nhận → `import-students` kiểm tra lại quyền và dữ liệu ở server → nhập theo giao dịch, giữ nguyên mã học sinh, trả số thêm/sửa/bỏ qua/lỗi. Không tự ghi đè âm thầm; việc cập nhật bản ghi hiện có cần được hiển thị và xác nhận. Không lưu file gốc lâu dài và không ghi tên/mã/token vào log. Có thể tải báo cáo lỗi theo số dòng.

Luồng học sinh mặc định: website cho chọn lớp từ danh mục được cung cấp an toàn, nhập họ tên; server đối chiếu tên đã chuẩn hóa trong lớp. Nếu khớp đúng một học sinh, tiếp tục. Nếu trùng tên trong lớp, yêu cầu mã học sinh; nếu không khớp hoặc mã không hợp lệ thì không tạo lượt và không tiết lộ danh sách bạn trong lớp. Nếu lớp chưa có roster, không tạo kết quả gắn với học sinh tùy tiện; yêu cầu giáo viên nhập roster trước.

`start-attempt` xác minh JWT anonymous, lớp/game đang hoạt động, rồi tra roster phía server; nó tạo snapshot đúng của học sinh/lớp/trò và `started_at` server. Nếu tên/lớp duy nhất khớp, không yêu cầu mã; nếu có tên trùng mới yêu cầu mã theo xác nhận của bạn. Lớp có thể đổi sau này, nhưng lượt cũ giữ `class_id_at_play` và tên lớp snapshot.

## 6. Xác minh điểm và Edge Functions

### Luồng chấm phía máy chủ

1. **`start-attempt`** nhận JWT anonymous, tên, lớp, mã chỉ khi cần. Kiểm tra claim `is_anonymous`, dữ liệu hợp lệ, lớp/game hoạt động, khớp roster và giới hạn tốc độ. Tạo hàng `game_attempts` mới với `status='in_progress'`, `verification_status='pending'`, gắn `student_auth_uid=auth.uid()` và mốc bắt đầu do server tạo. Trả dữ liệu hiển thị không chứa đáp án chuẩn.
2. **`submit-answer`** nhận `attempt_id`, `item_code` và câu trả lời/hoán vị. Xác minh lượt còn mở và thuộc JWT đó; item thuộc game/version đã bắt đầu; payload hợp lệ; request không vượt giới hạn. Đọc đáp án từ `private.game_items`, tính đúng/sai phía server và append response. Cho phép gửi lại câu trả lời nếu sai, đúng như luật hiện tại; khi item đã đúng thì không cho tính điểm item đó lần nữa. Với `steps`, kiểm tra thứ tự hoán vị đúng mà không thay đổi giao diện di chuyển lên/xuống hoặc thông báo hiện tại. Phản hồi Function chỉ cho biết đúng/sai để giao diện hiện thông báo hiện có; không trả đáp án chuẩn.
3. **`complete-attempt`** xác nhận mọi item bắt buộc đã được giải đúng theo logic hiện tại; tự tổng hợp số item được tính điểm (không đếm số lần thử sai), không nhận tổng điểm đáng tin từ client; tính điểm/tỷ lệ/thời lượng; ghi `completed_at=now()`; chuyển trạng thái sang `completed`, khóa bản ghi và đánh `server_verified`. Thời gian/tỷ lệ/số câu do browser gửi đều bị bỏ qua.
4. Mỗi request có idempotency key; retry cùng request trả kết quả của response đó, không ghi trùng. Lượt sai mới là request mới nên học sinh vẫn thử lại. Muốn chơi lại phải tạo attempt mới. Lượt bỏ dở cần job/RPC vận hành riêng để chuyển sang `abandoned` sau ngưỡng thời gian được cấu hình; phần này chưa có trong SQL draft.
5. Không gửi lại đáp án chuẩn trong bundle hoặc response API. Các câu và đáp án chuẩn của bốn trò trắc nghiệm cùng quy tắc thứ tự của `steps` phải được chuyển lên private schema. Client chỉ cần gửi lựa chọn đã bấm hoặc thứ tự hiện tại.

### Phân biệt trạng thái xác minh

`server_verified` nghĩa server tự kiểm tra câu trả lời và tính lại kết quả từ dữ liệu đã lưu. Đây là trạng thái dự kiến cho cả năm hoạt động theo luật hiện tại. `client_reported` chỉ dùng khi nhận điểm/tổng đúng do trình duyệt tự tính; có thể bị sửa bằng Developer Tools hoặc request giả, nên dashboard phải gắn nhãn “Trình duyệt báo cáo — chưa xác minh” và không trộn vào thống kê đã xác minh; draft hiện chưa cung cấp RPC ghi loại kết quả này. Nếu tương lai có hoạt động sáng tạo mở, không có đáp án chuẩn, giáo viên chấm sẽ là `teacher_reviewed`; chưa đánh giá là `not_applicable`. Không đánh dấu tự động `server_verified` cho kết quả do client tính.

Các Edge Functions user-facing giữ JWT verification mặc định bật. Supabase khuyến nghị xác minh JWT cho các hàm chỉ gọi bởi người dùng đã đăng nhập [2] [3]. Anonymous Auth có thể bị lạm dụng để tạo phiên, nên bật CAPTCHA/Turnstile và rate-limit [6] [7].

## 7. Phân quyền, RLS và quản trị viên tối cao

- **Quản trị viên tối cao:** tài khoản Supabase Auth do chủ hệ thống sở hữu; role `super_admin` được cấp thủ công qua quy trình quản trị an toàn, không có đăng ký tự phục vụ. Có thể quản lý roster toàn trường, lớp, tài khoản giáo viên, phân công, kết quả toàn trường và xuất toàn bộ. Việc cấp admin mới phải được bảo vệ riêng, có audit; không tin `user_metadata` tự sửa.
- **Giáo viên:** đăng nhập Supabase Auth bằng email/password hoặc magic link; chỉ xem/quản lý roster, lượt chơi, import/export thuộc các lớp trong `teacher_classes`. Không thể xem lớp khác bằng cách thay filter/URL.
- **Học sinh:** không có tài khoản cá nhân. Phiên anonymous chỉ tạo lượt qua Edge Functions; không có SELECT/UPDATE/DELETE trên roster hoặc kết quả. Function chỉ trả nội dung bài/lượt hiện tại, không trả dữ liệu học sinh khác.
- Bật RLS trên `students`, `classes`, `teacher_profiles`, `teacher_classes`, `games`, `game_attempts`, `attempt_responses` và audit tables. Không cấp GRANT rộng cho `anon`; truy vấn giáo viên qua JWT + policy kiểm tra role/lớp. Policy học sinh phải kiểm tra claim `is_anonymous`; vai trò giáo viên chỉ lấy từ hồ sơ/phân công do admin quản lý hoặc claim do server phát hành [4] [6].
- Không có client `UPDATE` trên kết quả đã hoàn tất. Server-only writes dùng service-role nếu thật cần thiết, chỉ trong function; vì key bypass RLS, function phải kiểm tra caller, owner attempt, lớp, game/version, trạng thái và kiểu dữ liệu trước khi ghi [1] [2].
- Không public endpoint xem bảng xếp hạng. Views/RPC thống kê phải tôn trọng quyền người gọi; policy kiểm thử phải phủ chéo học sinh A/B, giáo viên lớp A/B và admin [1].

## 8. Trang quản trị giáo viên

`/teacher` là giao diện riêng nhưng ẩn URL không phải bảo mật. Có đăng nhập, roster, nhập Excel, kết quả, thống kê, xếp hạng nội bộ và xuất Excel. Admin thấy toàn trường; giáo viên chỉ các lớp được giao.

Trang kết quả lọc lớp, trò chơi, năm học, ngày, trạng thái hoàn thành và xác minh. Từng học sinh có trang chi tiết mã/họ tên/lớp và lịch sử mọi lượt. Dòng kết quả có mã/tên trò, điểm, đúng/tổng, tỷ lệ đúng, thời lượng, thời điểm hoàn thành, trạng thái và nhãn `server_verified`/trạng thái khác.

Theo từng học sinh và trò chơi, hiển thị điểm cao nhất, điểm gần nhất, số lần chơi. Thống kê lớp: số lượt, số học sinh đã chơi, điểm trung bình, điểm cao nhất, tỷ lệ đúng, thời lượng; tỷ lệ chung dùng `sum(correct_count)/sum(question_count) × 100` và phân biệt với trung bình tỷ lệ từng lượt. Xếp hạng chỉ trong dashboard được phân quyền, không công khai; mặc định điểm cao trước, hòa thì tỷ lệ đúng cao hơn rồi thời lượng ngắn hơn. Lượt chưa hoàn thành không xếp hạng. `client_reported` phải được lọc/hiển thị riêng.

## 9. Xuất dữ liệu Excel

Giáo viên chọn lớp được phân công, game và khoảng ngày; admin tối cao có thêm “toàn trường”. Một dòng cho mỗi attempt, không gộp/ghi đè lịch sử. Có thể có worksheet kết quả và worksheet tổng hợp. `export-results` xác minh JWT, role, phạm vi lớp ở server; ghi audit người xuất, filter, thời gian, số dòng. Không lưu file trong public Storage. Xuất các chuỗi bắt đầu bằng `=`, `+`, `-`, `@` dưới dạng text an toàn để tránh spreadsheet formula injection. File export là báo cáo, không phải backup đầy đủ.

## 10. Sao lưu và khôi phục cho Supabase Free

Tài liệu Supabase khuyến nghị các project Free tự xuất dữ liệu định kỳ bằng Supabase CLI và lưu bản off-site; backup database tự động hằng ngày áp dụng Pro/Team/Enterprise. Backup DB không bao gồm object lưu trong Supabase Storage [8]. Vì vậy, đề xuất cho project Free:

1. **Tần suất:** mỗi đêm dump logic database sau giờ học/giờ ít sử dụng; sau đó giữ bản lăn 30 ngày (đề xuất ban đầu, cần theo chính sách nhà trường). Sau mỗi thay đổi schema/function quan trọng, tạo thêm bản backup trước thay đổi. Gửi cảnh báo vận hành khi backup thất bại; không xóa dữ liệu dự án để “dọn” backup.
2. **Phạm vi:** lưu migration/schema và dữ liệu cần thiết cho `classes`, `students`, `games`, `game_attempts`, `attempt_responses`, mapping giáo viên/audit phù hợp. Có quy trình riêng lưu mã nguồn/phiên bản Edge Functions, cấu hình Auth/RLS và các thiết lập project; dump database không tự mang theo toàn bộ các mục này. Hiện dự án chưa có Storage object roster/kết quả; nếu tương lai thêm, backup object riêng vì DB backup chỉ có metadata Storage [8] [9]. Thời hạn xóa tài khoản Auth ẩn danh hoặc hồ sơ/lượt học sinh chưa được chốt; không lập lịch tự xóa bất cứ dữ liệu nào trước khi bạn duyệt retention và quy trình khôi phục.
3. **Cách thực hiện:** người quản lý được ủy quyền cấu hình job ngoài Supabase (ví dụ máy tính quản trị luôn hoạt động hoặc runner riêng) dùng Supabase CLI `db dump` qua connection string bí mật lưu trong secret store của runner, không trong repository. Tạo dump roles/schema/data theo hướng dẫn CLI, mã hóa file trước khi tải lên nơi lưu ngoài project có ACL riêng. Không đưa database password, access token hoặc file chứa dữ liệu trẻ lên chat/email. Supabase CLI mô tả quy trình dump database; migration/restore cần xử lý riêng Auth settings, Edge Functions, Storage objects và cấu hình dự án [9].
4. **Kiểm tra:** hằng ngày job xác nhận dump không rỗng, checksum và thời gian hoàn tất; hằng tuần kiểm tra khả năng giải mã/đọc metadata không mở rộng quyền truy cập. Mỗi quý khôi phục bản gần nhất vào project test riêng, kiểm tra roster, lượt chơi, quan hệ, RLS, functions và đăng nhập; ghi biên bản kết quả.
5. **Khôi phục:** nếu có sự cố, đóng luồng ghi hoặc thông báo tạm ngưng; chọn bản backup đúng mốc, giải mã trong môi trường quản trị an toàn, tạo project khôi phục riêng hoặc khôi phục vào project đích theo runbook Supabase; nạp roles/schema/data theo thứ tự, triển khai lại functions/cấu hình/Auth riêng, rồi kiểm tra dữ liệu và RLS trước khi chuyển ứng dụng. Ưu tiên restore ra project mới để giữ nguyên bản hiện tại và đối chiếu trước; chỉ đổi kết nối production sau phê duyệt rõ ràng. Không xóa dữ liệu cũ như một phần tự động của kế hoạch này.
6. **PITR:** không đưa vào phương án Free mặc định; Supabase ghi PITR là add-on trên Pro/Team/Enterprise, có chi phí [8] [10]. Nếu sau này chuyển plan, đánh giá lại theo RPO/RTO và ngân sách.

## 11. Giữ nguyên trò chơi và tích hợp

Tích hợp dự kiến thêm adapter dùng chung bên ngoài khung mỗi hoạt động: nhận dạng học sinh trước khi vào, bắt đầu lượt, gửi lựa chọn/thứ tự để chấm server, rồi xác nhận lưu kết quả. Giữ nguyên tiêu đề, ảnh, màu sắc, câu chữ, hoạt ảnh, điều khiển, thứ tự nội dung, luật thử lại và cảm giác tương tác. Chuyển đáp án đúng ra server là thay đổi dữ liệu/luồng chấm nội bộ bắt buộc để bảo vệ đáp án, không thiết kế lại trò.

Mã hiện tại cho thấy đáp án nằm trong `App.tsx` và điểm `award()` lưu local progress. Trước tích hợp, mapping mỗi hoạt động được định nghĩa đúng như bảng phân loại; không nhận điểm cục bộ là server-verified. Khi mạng lỗi, không thông báo đã lưu thành công; retry bằng idempotency key. Không lưu họ tên/mã vào localStorage lâu dài.

## 12. Việc người dùng cần làm và phần Manus có thể tiếp tục

**Bạn cần làm trước khi triển khai:**

- Xác nhận người sở hữu tài khoản admin tối cao (tài khoản Supabase Auth cụ thể) và cách cấp tài khoản giáo viên; không gửi mật khẩu/secret qua chat.
- Chuẩn bị roster Excel theo mã duy nhất toàn trường và lớp hiện hành; thống nhất định dạng `class_code`, cách cập nhật khi chuyển lớp.
- Chốt retention chính thức cho dữ liệu trẻ và backup, nơi lưu backup ngoài project, ai được truy cập/khôi phục; chọn thiết bị/runner đáng tin cậy có thể chạy dump hằng đêm và giữ secret an toàn.
- Xác nhận thang điểm 0–100, quy tắc với lượt bỏ dở, và việc `steps` được tính như một mục sắp xếp đúng/sai; đề xuất trong tài liệu là 1 mục, 100% khi hoàn thành đúng.
- Xác nhận có thể dùng project Supabase test riêng để thử schema/RLS/khôi phục trước khi production.

**Manus có thể làm sau một phê duyệt triển khai riêng:** kiểm tra cấu hình/schema Supabase chỉ đọc; soạn migration và policy để bạn xem trước; triển khai roster/import, Edge Functions, trang quản trị và adapter cho 5 hoạt động; thử trên dữ liệu giả; hướng dẫn cấu hình job backup và kiểm thử khôi phục. Chỉ sau chấp thuận rõ ràng mới tạo bảng/chạy SQL, thêm secrets hoặc bật ghi dữ liệu. Xuất bản website cần phê duyệt riêng. Hiện tại chưa bắt đầu các việc này.

## 13. SQL migration dự kiến để rà soát

Bản migration chi tiết nằm trong [tệp SQL dự thảo — không chạy](/home/ubuntu/thegioiart-results-schema-draft.sql). Tệp gồm DDL cho các bảng roster/lớp/giáo viên/trò/lượt/đáp án/audit; unique constraints/indexes; RLS và GRANT; ba dashboard views `security_invoker`; các RPC `edge_start_attempt`, `edge_submit_answer`, `edge_complete_attempt` chỉ cho `service_role`; cùng seed mã trò hiện tại. Xếp hạng tính một kết quả tốt nhất mỗi học sinh/trò/lớp và chỉ lấy `server_verified`; summary phân tách theo trạng thái xác minh.

Tệp cố ý không chứa nội dung đáp án chuẩn cụ thể, không có `DROP`, `TRUNCATE` hay `DELETE`, và chưa thực thi. Nó vẫn **chưa phải migration áp dụng được ngay**: chưa kiểm tra schema/grants/RLS hiện hữu hoặc xung đột tên trong Supabase; câu hỏi/đáp án cần ánh xạ và duyệt theo phiên bản game; admin tối cao phải được bootstrap bằng Auth user UUID chính xác sau khi xác nhận; Edge Functions `import-students`, `export-results`, `list-student-classes` và job/RPC đóng lượt bỏ dở là phần ứng dụng/vận hành riêng, không được tạo chỉ bằng SQL này. Các view dùng `security_invoker` nên trước khi áp dụng cần xác nhận PostgreSQL hỗ trợ tùy chọn này (PostgreSQL 15 trở lên). Trước khi áp dụng, cần kiểm tra trên project test và rà soát SQL cuối cùng. `private` phải không nằm trong schema được expose qua Data API. Edge Functions phải xác thực JWT bằng user context trước khi dùng server-side service key gọi RPC; không gọi RPC service-role từ browser.

**Phạm vi tuyệt đối hiện tại:** tạo tài liệu SQL để bạn xem; không kết nối tới Supabase, không chạy migration, không tạo bảng hay sửa grants/RLS, không thêm khóa và không xóa dữ liệu.

## Tài liệu tham khảo

[1]: https://supabase.com/docs/guides/database/postgres/row-level-security "Supabase Row Level Security"
[2]: https://supabase.com/docs/guides/functions/auth "Securing Supabase Edge Functions"
[3]: https://supabase.com/docs/guides/functions/auth-headers "Supabase Edge Function Authorization Headers"
[4]: https://supabase.com/docs/guides/api/custom-claims-and-role-based-access-control-rbac "Supabase Custom Claims and RBAC"
[5]: https://supabase.com/docs/guides/auth "Supabase Auth"
[6]: https://supabase.com/docs/guides/auth/auth-anonymous "Supabase Anonymous Sign-Ins"
[7]: https://supabase.com/docs/guides/auth/auth-captcha "Supabase CAPTCHA Protection"
[8]: https://supabase.com/docs/guides/platform/backups "Supabase Database Backups"
[9]: https://supabase.com/docs/guides/platform/migrating-within-supabase/backup-restore "Supabase Backup and Restore using the CLI"
[10]: https://supabase.com/docs/guides/platform/manage-your-usage/point-in-time-recovery "Supabase Point-in-Time Recovery Usage"
