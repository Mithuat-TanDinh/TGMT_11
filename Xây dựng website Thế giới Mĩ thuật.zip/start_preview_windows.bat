@echo off
setlocal
cd /d "%~dp0ready-to-run"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m http.server 8765 --bind 127.0.0.1
) else (
  python -m http.server 8765 --bind 127.0.0.1
)
echo.
echo May chu da dung. Nhan phim bat ky de dong cua so.
pause >nul
