# Thế giới Mĩ thuật

Website tương tác tiếng Việt cho học sinh tiểu học lớp 1–5. Đây là bản xem trước trong Manus; chưa kết nối Supabase, GitHub hoặc Netlify và chưa xuất bản.

## Chạy dự án

Yêu cầu Node.js 22 và pnpm 11. Tại thư mục dự án, chạy `pnpm install`, sau đó `pnpm dev`. Mở cổng 3000 do Vite khởi chạy.

## Bản xem trước

Trang chủ dẫn đến Góc Âm nhạc, Trò chơi học tập, Thế giới Khám phá, Xưởng Sáng tạo, Thành tích và Góc giáo viên. Các hoạt động trong Xưởng Sáng tạo chạy ngay. Có thể thêm MP3 (tối đa 15 MB) và ảnh bìa (tối đa 1,5 MB), quản lý metadata và đường dẫn trò chơi trong các hộp thoại tương ứng. Tệp âm thanh/hình lưu trong IndexedDB; danh mục, liên kết và tiến độ lưu trong bộ nhớ trình duyệt của thiết bị hiện tại. Có thể xóa dữ liệu khi xóa dữ liệu trang web trong trình duyệt. Không dùng dữ liệu thật của học sinh; không có sao lưu hay đồng bộ sang thiết bị khác.

Đây không phải hệ thống xác thực. Góc giáo viên được hiển thị rõ là bản xem trước cục bộ và không bảo vệ bằng đăng nhập; không dùng để quản lý nội dung nhạy cảm hoặc công khai trên Internet.

## Tích hợp sau này

Kết nối Supabase cần cấu hình Auth, Database, Storage và Row Level Security (RLS) trước khi bật quản trị thật. Mẫu `.env.example` chỉ nêu hai giá trị cấu hình trình duyệt; anon/publishable key vốn hiển thị ở trình duyệt và chỉ an toàn khi chính sách RLS đã hạn chế đúng quyền. Không bao giờ đưa `service_role` key hoặc khóa bí mật vào mã client/GitHub. Chưa có thiết lập Supabase/Netlify/GitHub trong phiên bản này.

## Khu vực đã dựng

- **Góc Âm nhạc:** phát/tạm dừng/tiếp theo/trước đó, âm lượng, tìm kiếm, lọc theo khối, nhập MP3, lời bài hát và ảnh bìa; tất cả chỉ cục bộ.
- **Trò chơi học tập:** lọc lớp 1–5, lưu tên/mô tả/lớp/URL, thử nhúng iframe và mở tab mới; trò chơi đích có thể cấm nhúng.
- **Xưởng Sáng tạo:** ghép câu với hình, xếp bước vẽ, màu sắc, hình cơ bản và nhận biết sản phẩm Mĩ thuật.
- **Thế giới Khám phá:** bản đồ minh họa/nhiệm vụ giới thiệu hướng phát triển của game độc lập sau này.
- **Thành tích:** điểm/huy hiệu ẩn danh, lưu trên thiết bị.

## Quyền riêng tư và an toàn

Chưa có tài khoản, phân quyền, API server hay kho media dùng chung. Các URL iframe bên ngoài vẫn do nhà cung cấp tương ứng kiểm soát; trang bên ngoài có thể không nhúng được. Dùng tên miền HTTPS cho các liên kết trò chơi khi có thể.
