#!/bin/sh
set -eu
cd "$(dirname "$0")/ready-to-run"
echo "Dang phuc vu ban xem thu tai http://127.0.0.1:8765"
echo "Nhan Ctrl+C de dung may chu."
python3 -m http.server 8765 --bind 127.0.0.1
