# TODO — Thế giới Mĩ thuật

## Trang chủ và điều hướng — hoàn thành bản xem trước
- Có logo và tên Thế giới Mĩ thuật.
- Có lời chào học sinh.
- Các khu vực chức năng được thể hiện thành bản đồ hoặc các nút lớn.
- Giao diện hoạt hình 2D, thế giới cổ tích, vui nhộn, nhiều màu sắc; phù hợp học sinh tiểu học.
- Nút lớn, chữ rõ ràng, tiếng Việt có dấu; có hình minh họa riêng cho từng khu vực.
- Tương thích màn hình điện thoại và máy tính; hiệu ứng chuyển trang nhẹ, không gây chậm.

## Góc Âm nhạc — hoàn thành bản xem trước cục bộ
- Có danh sách bài hát MP3 và tìm kiếm bài hát.
- Có thể tải MP3 từ máy tính trong phiên bản xem trước; kiểm tra định dạng và dung lượng; có thông báo khi tải thành công/thất bại.
- Có trình phát Play, Pause, Next, Previous, Volume; hiển thị tên bài, ảnh đại diện, lời bài hát nếu được nhập.
- Có thể phân loại theo chủ đề và khối lớp; thêm, sửa, xóa bài hát trong lưu trữ của trình duyệt hiện tại.
- Khi chưa có nội dung do giáo viên cung cấp, hiển thị trạng thái trống, không tạo dữ liệu giả.
- MP3/ảnh lưu trên Supabase Storage và thư viện dùng chung chưa được kết nối trong bản xem trước; dữ liệu cục bộ không đồng bộ sang thiết bị khác.

## Khu trò chơi học tập — hoàn thành bản xem trước cục bộ
- Chia trò chơi theo lớp 1, 2, 3, 4, 5.
- Giáo viên có thể thêm trò chơi bằng cách nhập tên, mô tả, khối lớp và URL; sửa/xóa link trong trình duyệt hiện tại.
- Nhúng trò chơi bằng iframe nếu trò chơi cho phép; có nút Mở trò chơi trong cửa sổ/tab mới.
- Hỗ trợ URL trò chơi đã xuất bản trên Netlify; không viết lại hoặc làm thay đổi mã nguồn trò chơi hiện có.
- Có thông báo phù hợp khi URL không hợp lệ hoặc trang đích chặn nhúng; việc mở tab mới vẫn được cung cấp.
- Danh mục trò chơi không được điền bằng dữ liệu giả.

## Thế giới Khám phá — hoàn thành khu vực định hướng cho giai đoạn tiếp theo
- Có khu vực giới thiệu hành trình/game nhập vai 2D riêng cho giai đoạn tiếp theo.
- Thể hiện phong cách phiêu lưu làng quê cổ tích; có bản đồ, nhân vật, nhiệm vụ, vật phẩm và điểm thưởng ở dạng thiết kế/preview, không tuyên bố đây đã là game độc lập hoàn chỉnh.

## Xưởng Sáng tạo — hoàn thành hoạt động xem trước
- Có hoạt động ghép hình/từ với câu.
- Có hoạt động sắp xếp các bước vẽ.
- Có hoạt động nhận biết màu sắc.
- Có hoạt động nhận biết hình cơ bản.
- Có hoạt động nhận biết sản phẩm Mĩ thuật.
- Các hoạt động chạy được ngay trong website và phản hồi kết quả/điểm.

## Thành tích và quyền riêng tư — hoàn thành bản xem trước cục bộ
- Hiển thị nhiệm vụ đã hoàn thành, điểm số và huy hiệu học tập.
- Lưu tiến độ preview ở trình duyệt hiện tại; không yêu cầu/hiển thị công khai thông tin cá nhân nhạy cảm.
- Không tuyên bố đồng bộ liên thiết bị khi chưa có database.

## Khu quản trị giáo viên — giao diện xem trước hoàn thành; CRUD nhiệm vụ/xác thực an toàn còn mở
- Có giao diện khu quản trị được ghi nhãn cục bộ và luồng quản lý bài hát/URL trò chơi; liên kết nhiệm vụ đưa tới xưởng sáng tạo.
- Thêm/sửa/xóa nhiệm vụ và câu hỏi học tập từ trang quản trị chưa được triển khai.
- Hiển thị cảnh báo rõ rằng phiên bản xem trước lưu cục bộ và chưa xác thực/không được dùng để bảo vệ dữ liệu thật.
- Đăng nhập giáo viên an toàn, phân quyền quản trị, quản lý nội dung/thành tích trên backend và không để mật khẩu/khóa bí mật trong JavaScript công khai chỉ được coi là hoàn tất sau khi cấu hình Supabase Auth/Database/Storage và chính sách truy cập phù hợp.

## Tích hợp và bàn giao ngoài phạm vi bản xem trước hiện tại — chờ cấu hình/ủy quyền
- Chưa kết nối Supabase Database/Storage; không lưu MP3 trực tiếp trong mã nguồn.
- Chưa kết nối GitHub hoặc Netlify; không xuất bản website.
- Không tự ý xóa hoặc ghi đè dự án Netlify hiện có.
- Trước mọi thao tác có thể ghi đè dự án hoặc thay đổi dữ liệu hiện có, phải xin xác nhận của giáo viên.
- Hướng dẫn Supabase/Netlify/GitHub, triển khai thật, sao lưu và cập nhật sẽ được hoàn thiện khi giáo viên yêu cầu kết nối/xuất bản.
