-- THẾ GIỚI MĨ THUẬT — MIGRATION DRAFT FOR REVIEW ONLY
-- DO NOT EXECUTE against any Supabase project at this stage.
-- No project schema/RLS has been inspected in this step. Before implementation:
--   1) inspect existing schemas, tables, grants, RLS, API-exposed schemas and Auth users;
--   2) reconcile names/types/constraints with what already exists;
--   3) use a test project and a separately approved final migration.
-- This draft contains DDL, role grants/policies, seed catalog rows and RPC definitions.
-- It intentionally contains no destructive DROP/TRUNCATE/DELETE statements.
-- It does not seed canonical answer content: that must be reviewed/mapped per game version.

BEGIN;

-- -----------------------------------------------------------------------------
-- 1. Private schema and table definitions
-- Ensure `private` is NOT in Supabase project's exposed Data API schemas.
-- Public RPC wrappers below are executable only by service_role.
-- -----------------------------------------------------------------------------

CREATE SCHEMA private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon, authenticated;
GRANT USAGE ON SCHEMA private TO authenticated, service_role;

CREATE TABLE public.teacher_profiles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE RESTRICT,
  display_name text NOT NULL CHECK (length(btrim(display_name)) BETWEEN 1 AND 120),
  role text NOT NULL CHECK (role IN ('super_admin', 'teacher')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE public.teacher_profiles IS
  'Staff accounts; role rows are provisioned by the system super admin, never by a student/client self-registration.';

CREATE TABLE public.classes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_code text NOT NULL CHECK (class_code = upper(btrim(class_code)) AND length(class_code) BETWEEN 1 AND 40),
  class_name text NOT NULL CHECK (length(btrim(class_name)) BETWEEN 1 AND 80),
  grade smallint NOT NULL CHECK (grade BETWEEN 1 AND 5),
  school_year text NOT NULL CHECK (length(btrim(school_year)) BETWEEN 1 AND 20),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_year, class_code)
);
COMMENT ON TABLE public.classes IS
  'School classes by school year. Archive with active=false; do not cascade-delete learning history.';

CREATE TABLE public.teacher_classes (
  teacher_id uuid NOT NULL REFERENCES public.teacher_profiles(user_id) ON DELETE RESTRICT,
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE RESTRICT,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (teacher_id, class_id)
);
COMMENT ON TABLE public.teacher_classes IS
  'Server-managed assignment of teachers to classes. Admin revokes an assignment by setting active=false.';

CREATE TABLE public.students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_code text NOT NULL UNIQUE
    CHECK (student_code = upper(btrim(student_code)) AND length(student_code) BETWEEN 1 AND 64),
  full_name text NOT NULL CHECK (length(btrim(full_name)) BETWEEN 1 AND 160),
  current_class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE RESTRICT,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE public.students IS
  'Minimal school roster. student_code is unique school-wide and not changed when the student moves class.';

CREATE TABLE public.games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_code text NOT NULL UNIQUE
    CHECK (game_code = lower(btrim(game_code)) AND length(game_code) BETWEEN 1 AND 64),
  game_name text NOT NULL CHECK (length(btrim(game_name)) BETWEEN 1 AND 160),
  current_version integer NOT NULL DEFAULT 1 CHECK (current_version > 0),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE public.games IS
  'Shared catalog for current and future learning activities. Historical attempts keep a name/code/version snapshot.';

CREATE TABLE private.game_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES public.games(id) ON DELETE RESTRICT,
  game_version integer NOT NULL CHECK (game_version > 0),
  item_code text NOT NULL CHECK (length(btrim(item_code)) BETWEEN 1 AND 80),
  item_order smallint NOT NULL CHECK (item_order > 0),
  -- prompt_payload is safe-to-render content (prompt/options), never include the answer key here.
  prompt_payload jsonb NOT NULL CHECK (jsonb_typeof(prompt_payload) = 'object'),
  -- answer_key is secret server-side data; never return it from an Edge Function to the browser.
  answer_key jsonb NOT NULL CHECK (jsonb_typeof(answer_key) IN ('object', 'array', 'string', 'number', 'boolean')),
  points numeric(7,2) NOT NULL DEFAULT 1 CHECK (points > 0),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (game_id, game_version, item_code),
  UNIQUE (game_id, game_version, item_order)
);
COMMENT ON TABLE private.game_items IS
  'Private question bank and answer keys for server scoring; this schema must remain absent from API-exposed schemas.';

CREATE TABLE public.game_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  start_idempotency_key uuid NOT NULL UNIQUE,
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE RESTRICT,
  class_id_at_play uuid NOT NULL REFERENCES public.classes(id) ON DELETE RESTRICT,
  game_id uuid NOT NULL REFERENCES public.games(id) ON DELETE RESTRICT,
  game_code_snapshot text NOT NULL,
  game_name_snapshot text NOT NULL,
  game_version integer NOT NULL CHECK (game_version > 0),
  student_code_snapshot text NOT NULL,
  student_name_snapshot text NOT NULL,
  class_name_snapshot text NOT NULL,
  student_auth_uid uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  score numeric(5,2) CHECK (score BETWEEN 0 AND 100),
  correct_count integer CHECK (correct_count >= 0),
  question_count integer CHECK (question_count >= 0),
  correct_rate numeric(5,2) CHECK (correct_rate BETWEEN 0 AND 100),
  duration_seconds integer CHECK (duration_seconds >= 0),
  started_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  completed_at timestamptz,
  abandoned_at timestamptz,
  status text NOT NULL DEFAULT 'in_progress'
    CHECK (status IN ('in_progress', 'completed', 'abandoned')),
  verification_status text NOT NULL DEFAULT 'pending'
    CHECK (verification_status IN ('pending', 'server_verified', 'client_reported', 'teacher_reviewed', 'not_applicable')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (
    (status = 'in_progress' AND completed_at IS NULL AND abandoned_at IS NULL)
    OR (status = 'completed' AND completed_at IS NOT NULL AND abandoned_at IS NULL)
    OR (status = 'abandoned' AND completed_at IS NULL AND abandoned_at IS NOT NULL)
  ),
  CHECK (
    question_count IS NULL OR correct_count IS NULL OR correct_count <= question_count
  ),
  CHECK (
    question_count IS NULL
    OR (question_count > 0 AND correct_rate IS NOT NULL)
    OR (question_count = 0 AND correct_rate IS NULL)
  ),
  CHECK (
    status <> 'completed'
    OR (score IS NOT NULL AND correct_count IS NOT NULL AND question_count IS NOT NULL
        AND correct_rate IS NOT NULL AND duration_seconds IS NOT NULL)
  ),
  CHECK (verification_status <> 'server_verified' OR status = 'completed')
);
COMMENT ON TABLE public.game_attempts IS
  'Append-only play history: one row per attempt, immutable snapshots, server timestamps, and explicit verification state.';

CREATE TABLE public.attempt_responses (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  attempt_id uuid NOT NULL REFERENCES public.game_attempts(id) ON DELETE RESTRICT,
  game_item_id uuid NOT NULL REFERENCES private.game_items(id) ON DELETE RESTRICT,
  answer_value jsonb NOT NULL CHECK (jsonb_typeof(answer_value) IN ('object', 'array', 'string', 'number', 'boolean')),
  is_correct boolean NOT NULL,
  idempotency_key uuid NOT NULL,
  answered_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (attempt_id, idempotency_key)
);
COMMENT ON TABLE public.attempt_responses IS
  'Server-recorded answer events. Wrong retries are retained; only the first correct response per item contributes to score.';

CREATE UNIQUE INDEX attempt_responses_one_correct_per_item
  ON public.attempt_responses (attempt_id, game_item_id)
  WHERE is_correct;

CREATE TABLE public.student_import_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  class_id uuid NOT NULL REFERENCES public.classes(id) ON DELETE RESTRICT,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  status text NOT NULL CHECK (status IN ('previewed', 'committed', 'failed')),
  row_count integer NOT NULL DEFAULT 0 CHECK (row_count >= 0),
  inserted_count integer NOT NULL DEFAULT 0 CHECK (inserted_count >= 0),
  updated_count integer NOT NULL DEFAULT 0 CHECK (updated_count >= 0),
  skipped_count integer NOT NULL DEFAULT 0 CHECK (skipped_count >= 0),
  error_count integer NOT NULL DEFAULT 0 CHECK (error_count >= 0),
  file_sha256 text CHECK (file_sha256 IS NULL OR file_sha256 ~ '^[0-9a-f]{64}$'),
  created_at timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE public.student_import_batches IS
  'Audit metadata for roster imports; do not persist uploaded workbook contents here.';

CREATE TABLE public.result_export_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  filters jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(filters) = 'object'),
  row_count integer NOT NULL DEFAULT 0 CHECK (row_count >= 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE public.result_export_audit IS
  'Audit metadata only; do not store exported student result rows in this table.';

-- -----------------------------------------------------------------------------
-- 2. Indexes for dashboard filters and lookup
-- -----------------------------------------------------------------------------

CREATE INDEX students_class_name_lookup
  ON public.students (current_class_id, lower(btrim(full_name)))
  WHERE active;
CREATE INDEX teacher_classes_active_lookup
  ON public.teacher_classes (teacher_id, class_id)
  WHERE active;
CREATE INDEX game_items_version_order_lookup
  ON private.game_items (game_id, game_version, item_order)
  WHERE active;
CREATE INDEX game_attempts_class_completed_lookup
  ON public.game_attempts (class_id_at_play, completed_at DESC)
  WHERE status = 'completed';
CREATE INDEX game_attempts_student_game_lookup
  ON public.game_attempts (student_id, game_id, completed_at DESC);
CREATE INDEX game_attempts_game_completed_lookup
  ON public.game_attempts (game_id, completed_at DESC)
  WHERE status = 'completed';
CREATE INDEX attempt_responses_attempt_item_time_lookup
  ON public.attempt_responses (attempt_id, game_item_id, answered_at);

-- -----------------------------------------------------------------------------
-- 3. RLS helper functions
-- SECURITY DEFINER avoids recursive RLS while reading staff assignment tables.
-- Fixed empty search_path and schema-qualified object names are intentional.
-- -----------------------------------------------------------------------------

CREATE FUNCTION private.is_super_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT auth.uid() IS NOT NULL
     AND (auth.jwt() ->> 'is_anonymous') IS DISTINCT FROM 'true'
     AND EXISTS (
       SELECT 1
       FROM public.teacher_profiles AS tp
       WHERE tp.user_id = auth.uid()
         AND tp.role = 'super_admin'
         AND tp.active
     );
$$;

CREATE FUNCTION private.is_active_teacher()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT auth.uid() IS NOT NULL
     AND (auth.jwt() ->> 'is_anonymous') IS DISTINCT FROM 'true'
     AND EXISTS (
       SELECT 1
       FROM public.teacher_profiles AS tp
       WHERE tp.user_id = auth.uid()
         AND tp.role IN ('teacher', 'super_admin')
         AND tp.active
     );
$$;

CREATE FUNCTION private.can_access_class(p_class_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT p_class_id IS NOT NULL
     AND private.is_active_teacher()
     AND (
       private.is_super_admin()
       OR EXISTS (
         SELECT 1
         FROM public.teacher_classes AS tc
         WHERE tc.teacher_id = auth.uid()
           AND tc.class_id = p_class_id
           AND tc.active
       )
     );
$$;

REVOKE ALL ON FUNCTION private.is_super_admin() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.is_active_teacher() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.can_access_class(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.is_super_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION private.is_active_teacher() TO authenticated;
GRANT EXECUTE ON FUNCTION private.can_access_class(uuid) TO authenticated;

-- -----------------------------------------------------------------------------
-- 4. RLS and least-privilege grants
-- No direct client write access to attempts or response rows.
-- Students are never granted DELETE; archive roster/classes instead of deleting.
-- -----------------------------------------------------------------------------

ALTER TABLE public.teacher_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.teacher_classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attempt_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_import_batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.result_export_audit ENABLE ROW LEVEL SECURITY;
ALTER TABLE private.game_items ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.teacher_profiles FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.classes FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.teacher_classes FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.students FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.games FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.game_attempts FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.attempt_responses FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.student_import_batches FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.result_export_audit FROM PUBLIC, anon, authenticated;
REVOKE ALL ON private.game_items FROM PUBLIC, anon, authenticated;

GRANT ALL ON public.teacher_profiles, public.classes, public.teacher_classes,
  public.students, public.games, public.game_attempts, public.attempt_responses,
  public.student_import_batches, public.result_export_audit TO service_role;
GRANT ALL ON private.game_items TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.attempt_responses_id_seq TO service_role;

-- Read grants are not sufficient by themselves; every row is still gated by RLS.
GRANT SELECT ON public.teacher_profiles, public.classes, public.teacher_classes,
  public.students, public.games, public.game_attempts,
  public.student_import_batches, public.result_export_audit TO authenticated;

-- Roster can be managed by assigned staff; student_code is immutable via Data API.
GRANT INSERT (student_code, full_name, current_class_id, active)
  ON public.students TO authenticated;
GRANT UPDATE (full_name, current_class_id, active)
  ON public.students TO authenticated;

-- Administrators manage class/staff/assignment catalog; soft-disable instead of delete.
GRANT INSERT (class_code, class_name, grade, school_year, active)
  ON public.classes TO authenticated;
GRANT UPDATE (class_code, class_name, grade, school_year, active)
  ON public.classes TO authenticated;
GRANT INSERT (user_id, display_name, role, active)
  ON public.teacher_profiles TO authenticated;
GRANT UPDATE (display_name, role, active)
  ON public.teacher_profiles TO authenticated;
GRANT INSERT (teacher_id, class_id, active)
  ON public.teacher_classes TO authenticated;
GRANT UPDATE (active)
  ON public.teacher_classes TO authenticated;

CREATE POLICY teacher_profiles_read_self_or_admin
  ON public.teacher_profiles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR private.is_super_admin());
CREATE POLICY teacher_profiles_insert_admin
  ON public.teacher_profiles FOR INSERT TO authenticated
  WITH CHECK (private.is_super_admin());
CREATE POLICY teacher_profiles_update_admin
  ON public.teacher_profiles FOR UPDATE TO authenticated
  USING (private.is_super_admin())
  WITH CHECK (private.is_super_admin());

CREATE POLICY classes_read_assigned
  ON public.classes FOR SELECT TO authenticated
  USING (private.can_access_class(id));
CREATE POLICY classes_insert_admin
  ON public.classes FOR INSERT TO authenticated
  WITH CHECK (private.is_super_admin());
CREATE POLICY classes_update_admin
  ON public.classes FOR UPDATE TO authenticated
  USING (private.is_super_admin())
  WITH CHECK (private.is_super_admin());

CREATE POLICY teacher_classes_read_self_or_admin
  ON public.teacher_classes FOR SELECT TO authenticated
  USING (teacher_id = auth.uid() OR private.is_super_admin());
CREATE POLICY teacher_classes_insert_admin
  ON public.teacher_classes FOR INSERT TO authenticated
  WITH CHECK (private.is_super_admin());
CREATE POLICY teacher_classes_update_admin
  ON public.teacher_classes FOR UPDATE TO authenticated
  USING (private.is_super_admin())
  WITH CHECK (private.is_super_admin());

CREATE POLICY students_read_assigned
  ON public.students FOR SELECT TO authenticated
  USING (private.can_access_class(current_class_id));
CREATE POLICY students_insert_assigned
  ON public.students FOR INSERT TO authenticated
  WITH CHECK (private.can_access_class(current_class_id));
CREATE POLICY students_update_assigned
  ON public.students FOR UPDATE TO authenticated
  USING (private.can_access_class(current_class_id))
  WITH CHECK (private.can_access_class(current_class_id));

CREATE POLICY games_read_active_staff
  ON public.games FOR SELECT TO authenticated
  USING (active OR private.is_super_admin());
CREATE POLICY games_insert_admin
  ON public.games FOR INSERT TO authenticated
  WITH CHECK (private.is_super_admin());
CREATE POLICY games_update_admin
  ON public.games FOR UPDATE TO authenticated
  USING (private.is_super_admin())
  WITH CHECK (private.is_super_admin());

CREATE POLICY attempts_read_assigned_class
  ON public.game_attempts FOR SELECT TO authenticated
  USING (private.can_access_class(class_id_at_play));
-- Intentionally no client INSERT/UPDATE/DELETE policies for attempt rows.
-- Only the server-side RPCs below can create/finalize attempts.
-- Intentionally no client policies/grants on attempt_responses or private.game_items.

CREATE POLICY import_batches_read_assigned
  ON public.student_import_batches FOR SELECT TO authenticated
  USING (private.can_access_class(class_id));
CREATE POLICY export_audit_read_self_or_admin
  ON public.result_export_audit FOR SELECT TO authenticated
  USING (teacher_id = auth.uid() OR private.is_super_admin());

-- Dashboard aggregation views run with the querying teacher's privileges so
-- underlying game_attempts RLS remains in force. No student/public grants.
CREATE VIEW public.teacher_student_game_summary
WITH (security_invoker = true)
AS
SELECT
  a.class_id_at_play AS class_id,
  a.student_id,
  a.student_code_snapshot AS student_code,
  a.student_name_snapshot AS student_name,
  a.class_name_snapshot AS class_name,
  a.game_id,
  a.game_code_snapshot AS game_code,
  a.game_name_snapshot AS game_name,
  a.verification_status,
  count(*) FILTER (WHERE a.status = 'completed')::integer AS completed_attempts,
  max(a.score) FILTER (WHERE a.status = 'completed') AS highest_score,
  (array_agg(a.score ORDER BY a.completed_at DESC)
    FILTER (WHERE a.status = 'completed'))[1] AS latest_score,
  avg(a.score) FILTER (WHERE a.status = 'completed') AS average_score,
  max(a.completed_at) FILTER (WHERE a.status = 'completed') AS latest_completed_at
FROM public.game_attempts AS a
GROUP BY
  a.class_id_at_play, a.student_id, a.student_code_snapshot,
  a.student_name_snapshot, a.class_name_snapshot, a.game_id,
  a.game_code_snapshot, a.game_name_snapshot, a.verification_status;

CREATE VIEW public.teacher_class_game_stats
WITH (security_invoker = true)
AS
SELECT
  a.class_id_at_play AS class_id,
  a.game_id,
  a.game_code_snapshot AS game_code,
  a.game_name_snapshot AS game_name,
  a.verification_status,
  count(*) FILTER (WHERE a.status = 'completed')::integer AS completed_attempts,
  count(*) FILTER (WHERE a.status = 'abandoned')::integer AS abandoned_attempts,
  count(DISTINCT a.student_id) FILTER (WHERE a.status = 'completed')::integer AS students_played,
  avg(a.score) FILTER (WHERE a.status = 'completed') AS average_score,
  max(a.score) FILTER (WHERE a.status = 'completed') AS highest_score,
  sum(a.correct_count) FILTER (WHERE a.status = 'completed') AS correct_total,
  sum(a.question_count) FILTER (WHERE a.status = 'completed') AS question_total,
  CASE WHEN coalesce(sum(a.question_count) FILTER (WHERE a.status = 'completed'), 0) > 0
    THEN round(
      100 * sum(a.correct_count) FILTER (WHERE a.status = 'completed')::numeric
      / sum(a.question_count) FILTER (WHERE a.status = 'completed'),
      2
    )
    ELSE NULL
  END AS class_correct_rate
FROM public.game_attempts AS a
GROUP BY a.class_id_at_play, a.game_id, a.game_code_snapshot,
  a.game_name_snapshot, a.verification_status;

CREATE VIEW public.teacher_game_rankings
WITH (security_invoker = true)
AS
SELECT
  best.class_id,
  best.game_id,
  best.student_id,
  best.student_code,
  best.student_name,
  best.score,
  best.correct_rate,
  best.duration_seconds,
  best.completed_at,
  rank() OVER (
    PARTITION BY best.class_id, best.game_id
    ORDER BY best.score DESC, best.correct_rate DESC,
      best.duration_seconds ASC, best.completed_at ASC
  ) AS rank_in_class_game
FROM (
  SELECT DISTINCT ON (a.class_id_at_play, a.game_id, a.student_id)
    a.class_id_at_play AS class_id,
    a.game_id,
    a.student_id,
    a.student_code_snapshot AS student_code,
    a.student_name_snapshot AS student_name,
    a.score,
    a.correct_rate,
    a.duration_seconds,
    a.completed_at
  FROM public.game_attempts AS a
  WHERE a.status = 'completed'
    AND a.verification_status = 'server_verified'
  ORDER BY a.class_id_at_play, a.game_id, a.student_id,
    a.score DESC, a.correct_rate DESC, a.duration_seconds ASC, a.completed_at DESC
) AS best;

REVOKE ALL ON public.teacher_student_game_summary,
  public.teacher_class_game_stats, public.teacher_game_rankings
  FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.teacher_student_game_summary,
  public.teacher_class_game_stats, public.teacher_game_rankings TO authenticated;

-- -----------------------------------------------------------------------------
-- 5. Server-only RPCs
-- These public-schema wrappers must be called only by authenticated Edge Functions
-- using their server-side service_role key, after the function verifies the user's
-- JWT with Supabase Auth. Never call them from browser code and never expose keys.
-- -----------------------------------------------------------------------------

CREATE FUNCTION public.edge_start_attempt(
  p_verified_auth_uid uuid,
  p_full_name text,
  p_class_id uuid,
  p_game_code text,
  p_student_code text,
  p_start_idempotency_key uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_match_count integer;
  v_student_id uuid;
  v_student_code text;
  v_student_name text;
  v_class_name text;
  v_game_id uuid;
  v_game_name text;
  v_game_version integer;
  v_attempt_version integer;
  v_attempt_id uuid;
  v_items jsonb;
BEGIN
  IF p_verified_auth_uid IS NULL OR p_start_idempotency_key IS NULL THEN
    RAISE EXCEPTION 'INVALID_START_REQUEST';
  END IF;
  IF p_full_name IS NULL OR length(btrim(p_full_name)) = 0 THEN
    RAISE EXCEPTION 'STUDENT_NAME_REQUIRED';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.classes c WHERE c.id = p_class_id AND c.active
  ) THEN
    RAISE EXCEPTION 'CLASS_NOT_AVAILABLE';
  END IF;

  SELECT count(*) INTO v_match_count
  FROM public.students s
  WHERE s.current_class_id = p_class_id
    AND s.active
    AND lower(btrim(s.full_name)) = lower(btrim(p_full_name));

  IF v_match_count = 0 THEN
    RAISE EXCEPTION 'STUDENT_NOT_FOUND';
  ELSIF v_match_count > 1 AND (p_student_code IS NULL OR length(btrim(p_student_code)) = 0) THEN
    RAISE EXCEPTION 'STUDENT_CODE_REQUIRED_FOR_DUPLICATE_NAME';
  END IF;

  IF p_student_code IS NOT NULL AND length(btrim(p_student_code)) > 0 THEN
    SELECT s.id, s.student_code, s.full_name
      INTO v_student_id, v_student_code, v_student_name
    FROM public.students s
    WHERE s.current_class_id = p_class_id
      AND s.active
      AND lower(btrim(s.full_name)) = lower(btrim(p_full_name))
      AND s.student_code = upper(btrim(p_student_code));
    IF NOT FOUND THEN
      RAISE EXCEPTION 'STUDENT_NOT_FOUND';
    END IF;
  ELSE
    SELECT s.id, s.student_code, s.full_name
      INTO v_student_id, v_student_code, v_student_name
    FROM public.students s
    WHERE s.current_class_id = p_class_id
      AND s.active
      AND lower(btrim(s.full_name)) = lower(btrim(p_full_name));
  END IF;

  SELECT c.class_name INTO v_class_name
  FROM public.classes c WHERE c.id = p_class_id AND c.active;

  SELECT g.id, g.game_name, g.current_version
    INTO v_game_id, v_game_name, v_game_version
  FROM public.games g
  WHERE g.game_code = lower(btrim(p_game_code)) AND g.active;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'GAME_NOT_AVAILABLE';
  END IF;

  -- Retry of the same start request returns its original attempt without duplication.
  SELECT a.id, a.game_version INTO v_attempt_id, v_attempt_version
  FROM public.game_attempts a
  WHERE a.start_idempotency_key = p_start_idempotency_key;
  IF FOUND THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.game_attempts a
      WHERE a.id = v_attempt_id
        AND a.student_auth_uid = p_verified_auth_uid
        AND a.student_id = v_student_id
        AND a.game_id = v_game_id
    ) THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_REUSED';
    END IF;
    SELECT jsonb_agg(
      jsonb_build_object(
        'item_code', gi.item_code,
        'item_order', gi.item_order,
        'display', gi.prompt_payload
      ) ORDER BY gi.item_order
    ) INTO v_items
    FROM private.game_items gi
    WHERE gi.game_id = v_game_id
      AND gi.game_version = v_attempt_version
      AND gi.active;
    IF v_items IS NULL OR jsonb_array_length(v_items) = 0 THEN
      RAISE EXCEPTION 'GAME_CONTENT_NOT_READY';
    END IF;
    RETURN jsonb_build_object(
      'attempt_id', v_attempt_id,
      'game_code', lower(btrim(p_game_code)),
      'game_name', v_game_name,
      'game_version', v_attempt_version,
      'items', v_items
    );
  END IF;

  v_attempt_version := v_game_version;
  SELECT jsonb_agg(
    jsonb_build_object(
      'item_code', gi.item_code,
      'item_order', gi.item_order,
      'display', gi.prompt_payload
    ) ORDER BY gi.item_order
  ) INTO v_items
  FROM private.game_items gi
  WHERE gi.game_id = v_game_id
    AND gi.game_version = v_attempt_version
    AND gi.active;
  IF v_items IS NULL OR jsonb_array_length(v_items) = 0 THEN
    RAISE EXCEPTION 'GAME_CONTENT_NOT_READY';
  END IF;

  INSERT INTO public.game_attempts (
    start_idempotency_key,
    student_id, class_id_at_play, game_id,
    game_code_snapshot, game_name_snapshot, game_version,
    student_code_snapshot, student_name_snapshot, class_name_snapshot,
    student_auth_uid, started_at, status, verification_status
  ) VALUES (
    p_start_idempotency_key,
    v_student_id, p_class_id, v_game_id,
    lower(btrim(p_game_code)), v_game_name, v_game_version,
    v_student_code, v_student_name, v_class_name,
    p_verified_auth_uid, clock_timestamp(), 'in_progress', 'pending'
  ) RETURNING id INTO v_attempt_id;

  RETURN jsonb_build_object(
    'attempt_id', v_attempt_id,
    'game_code', lower(btrim(p_game_code)),
    'game_name', v_game_name,
    'game_version', v_game_version,
    'items', v_items
  );
END;
$$;
COMMENT ON FUNCTION public.edge_start_attempt(uuid, text, uuid, text, text, uuid) IS
  'Server-only RPC. Edge Function must verify JWT/is_anonymous and input before passing verified auth.uid(). Returns prompts/options but never answer_key.';

CREATE FUNCTION public.edge_submit_answer(
  p_verified_auth_uid uuid,
  p_attempt_id uuid,
  p_item_code text,
  p_answer_value jsonb,
  p_idempotency_key uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_attempt public.game_attempts%ROWTYPE;
  v_item_id uuid;
  v_answer_key jsonb;
  v_existing public.attempt_responses%ROWTYPE;
  v_correct boolean;
BEGIN
  IF p_verified_auth_uid IS NULL OR p_attempt_id IS NULL
     OR p_idempotency_key IS NULL OR p_answer_value IS NULL THEN
    RAISE EXCEPTION 'INVALID_ANSWER_REQUEST';
  END IF;

  SELECT a.* INTO v_attempt
  FROM public.game_attempts a
  WHERE a.id = p_attempt_id
  FOR UPDATE;
  IF NOT FOUND OR v_attempt.student_auth_uid IS DISTINCT FROM p_verified_auth_uid THEN
    RAISE EXCEPTION 'ATTEMPT_NOT_FOUND';
  END IF;
  IF v_attempt.status <> 'in_progress' THEN
    RAISE EXCEPTION 'ATTEMPT_NOT_OPEN';
  END IF;

  SELECT gi.id, gi.answer_key INTO v_item_id, v_answer_key
  FROM private.game_items gi
  WHERE gi.game_id = v_attempt.game_id
    AND gi.game_version = v_attempt.game_version
    AND gi.item_code = p_item_code
    AND gi.active;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'ITEM_NOT_FOUND';
  END IF;

  -- Idempotent retry of the exact same answer request.
  SELECT r.* INTO v_existing
  FROM public.attempt_responses r
  WHERE r.attempt_id = p_attempt_id
    AND r.idempotency_key = p_idempotency_key;
  IF FOUND THEN
    IF v_existing.game_item_id <> v_item_id
       OR v_existing.answer_value IS DISTINCT FROM p_answer_value THEN
      RAISE EXCEPTION 'IDEMPOTENCY_KEY_REUSED';
    END IF;
    RETURN jsonb_build_object('is_correct', v_existing.is_correct, 'duplicate', true);
  END IF;

  -- Do not count additional attempts after this item has already been solved.
  IF EXISTS (
    SELECT 1 FROM public.attempt_responses r
    WHERE r.attempt_id = p_attempt_id
      AND r.game_item_id = v_item_id
      AND r.is_correct
  ) THEN
    RETURN jsonb_build_object('is_correct', true, 'already_solved', true);
  END IF;

  v_correct := (p_answer_value = v_answer_key);
  INSERT INTO public.attempt_responses (
    attempt_id, game_item_id, answer_value, is_correct, idempotency_key
  ) VALUES (
    p_attempt_id, v_item_id, p_answer_value, v_correct, p_idempotency_key
  );

  -- No answer key or expected value is returned to the caller.
  RETURN jsonb_build_object('is_correct', v_correct, 'duplicate', false);
END;
$$;
COMMENT ON FUNCTION public.edge_submit_answer(uuid, uuid, text, jsonb, uuid) IS
  'Server-only RPC. Records every allowed try and checks it against private answer_key; returns only correct/incorrect.';

CREATE FUNCTION public.edge_complete_attempt(
  p_verified_auth_uid uuid,
  p_attempt_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_attempt public.game_attempts%ROWTYPE;
  v_question_count integer;
  v_correct_count integer;
  v_total_points numeric;
  v_earned_points numeric;
  v_completed_at timestamptz;
  v_duration integer;
  v_score numeric(5,2);
  v_rate numeric(5,2);
BEGIN
  IF p_verified_auth_uid IS NULL OR p_attempt_id IS NULL THEN
    RAISE EXCEPTION 'INVALID_COMPLETE_REQUEST';
  END IF;

  SELECT a.* INTO v_attempt
  FROM public.game_attempts a
  WHERE a.id = p_attempt_id
  FOR UPDATE;
  IF NOT FOUND OR v_attempt.student_auth_uid IS DISTINCT FROM p_verified_auth_uid THEN
    RAISE EXCEPTION 'ATTEMPT_NOT_FOUND';
  END IF;

  -- Safe idempotency: repeated completion returns the stored result.
  IF v_attempt.status = 'completed' THEN
    RETURN jsonb_build_object(
      'attempt_id', v_attempt.id,
      'status', v_attempt.status,
      'score', v_attempt.score,
      'correct_count', v_attempt.correct_count,
      'question_count', v_attempt.question_count,
      'correct_rate', v_attempt.correct_rate,
      'duration_seconds', v_attempt.duration_seconds,
      'completed_at', v_attempt.completed_at,
      'verification_status', v_attempt.verification_status
    );
  END IF;
  IF v_attempt.status <> 'in_progress' THEN
    RAISE EXCEPTION 'ATTEMPT_NOT_OPEN';
  END IF;

  SELECT count(*)::integer, coalesce(sum(gi.points), 0)
    INTO v_question_count, v_total_points
  FROM private.game_items gi
  WHERE gi.game_id = v_attempt.game_id
    AND gi.game_version = v_attempt.game_version
    AND gi.active;
  IF v_question_count = 0 OR v_total_points <= 0 THEN
    RAISE EXCEPTION 'GAME_CONTENT_NOT_READY';
  END IF;

  SELECT count(*)::integer, coalesce(sum(gi.points), 0)
    INTO v_correct_count, v_earned_points
  FROM private.game_items gi
  WHERE gi.game_id = v_attempt.game_id
    AND gi.game_version = v_attempt.game_version
    AND gi.active
    AND EXISTS (
      SELECT 1 FROM public.attempt_responses r
      WHERE r.attempt_id = p_attempt_id
        AND r.game_item_id = gi.id
        AND r.is_correct
    );

  IF v_correct_count <> v_question_count THEN
    RAISE EXCEPTION 'ATTEMPT_INCOMPLETE';
  END IF;

  v_completed_at := clock_timestamp();
  v_duration := greatest(0, floor(extract(epoch FROM (v_completed_at - v_attempt.started_at)))::integer);
  v_score := round(100 * v_earned_points / v_total_points, 2);
  v_rate := round(100 * v_correct_count::numeric / v_question_count, 2);

  UPDATE public.game_attempts
  SET score = v_score,
      correct_count = v_correct_count,
      question_count = v_question_count,
      correct_rate = v_rate,
      duration_seconds = v_duration,
      completed_at = v_completed_at,
      status = 'completed',
      verification_status = 'server_verified'
  WHERE id = p_attempt_id;

  RETURN jsonb_build_object(
    'attempt_id', p_attempt_id,
    'status', 'completed',
    'score', v_score,
    'correct_count', v_correct_count,
    'question_count', v_question_count,
    'correct_rate', v_rate,
    'duration_seconds', v_duration,
    'completed_at', v_completed_at,
    'verification_status', 'server_verified'
  );
END;
$$;
COMMENT ON FUNCTION public.edge_complete_attempt(uuid, uuid) IS
  'Server-only RPC. Recomputes the completed result exclusively from private game items and recorded correct responses.';

REVOKE ALL ON FUNCTION public.edge_start_attempt(uuid, text, uuid, text, text, uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.edge_submit_answer(uuid, uuid, text, jsonb, uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.edge_complete_attempt(uuid, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.edge_start_attempt(uuid, text, uuid, text, text, uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.edge_submit_answer(uuid, uuid, text, jsonb, uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.edge_complete_attempt(uuid, uuid) TO service_role;

-- -----------------------------------------------------------------------------
-- 6. Initial catalog entries only; does not seed prompts or answer keys.
-- ON CONFLICT DO NOTHING avoids changing an existing matching catalog row.
-- Reconcile any existing game_code/title/version before applying a real migration.
-- -----------------------------------------------------------------------------

INSERT INTO public.games (game_code, game_name, current_version, active)
VALUES
  ('match', 'Ghép hình với câu', 1, true),
  ('steps', 'Xếp bước vẽ', 1, true),
  ('colors', 'Nhà thám hiểm màu sắc', 1, true),
  ('shapes', 'Hình khối vui nhộn', 1, true),
  ('artworks', 'Bảo tàng tí hon', 1, true)
ON CONFLICT (game_code) DO NOTHING;

-- The first super_admin profile is a separate bootstrap action after confirming
-- the intended Auth user UUID. It is intentionally not guessed or seeded here.
-- Example ONLY; do not run with the placeholder:
-- INSERT INTO public.teacher_profiles (user_id, display_name, role, active)
-- VALUES ('<AUTH_USER_UUID_AFTER_APPROVAL>', '<ADMIN_DISPLAY_NAME>', 'super_admin', true);

COMMIT;

-- END OF REVIEW-ONLY DRAFT. No SQL in this file has been executed.
